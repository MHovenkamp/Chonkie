var searchData=
[
  ['namecolormode1',['nameColorMode1',['../classcolor_sensor.html#ad5be8be99e8a1f81bae6b76dc4f87ad5',1,'colorSensor']]],
  ['namecolormode2',['nameColorMode2',['../classcolor_sensor.html#ac48348507b372678c59accb63d438cdb',1,'colorSensor']]]
];
