var searchData=
[
  ['printrgb',['printRGB',['../classcolor_sensor.html#ad4b3ac74bb876323df70d3ab76b2022f',1,'colorSensor']]]
];
