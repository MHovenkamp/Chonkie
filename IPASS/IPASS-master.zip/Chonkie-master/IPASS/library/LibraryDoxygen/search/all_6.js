var searchData=
[
  ['sample',['sample',['../classfreq_measuringtool.html#a96dbb7e6ce2a8bad1be2eddfb727a3ec',1,'freqMeasuringtool']]],
  ['setblue',['setBlue',['../classcolor_sensor.html#aa4063c0f0e0031375ea9753368364805',1,'colorSensor']]],
  ['setclear',['setClear',['../classcolor_sensor.html#ac5bedfc4ea77ded6aaf230babc648548',1,'colorSensor']]],
  ['setgreen',['setGreen',['../classcolor_sensor.html#a8b3df81a757e90822689d74f715537ab',1,'colorSensor']]],
  ['setred',['setRed',['../classcolor_sensor.html#acbe0c89c3559b7ae95eeb0473e60c370',1,'colorSensor']]],
  ['shrinkvaluergb',['shrinkValueRGB',['../classcolor_sensor.html#a98f5a93723434fb1ccebe40a3ee5dd27',1,'colorSensor']]]
];
