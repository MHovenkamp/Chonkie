var searchData=
[
  ['calculate',['calculate',['../classfreq_measuringtool.html#a75fdfee8b84609b093591db5d175f392',1,'freqMeasuringtool']]],
  ['calculatecolor',['calculateColor',['../classcolor_sensor.html#aeffa1afc2007d9ac0936d74d43b8a8b3',1,'colorSensor']]],
  ['calculatelightintensity',['calculatelightIntensity',['../classcolor_sensor.html#aa61993c41f63d4c1e81800d700d8b65a',1,'colorSensor']]],
  ['calculatergb',['calculateRGB',['../classcolor_sensor.html#a0faa67ef4856d5e1332665e0a6aaba01',1,'colorSensor']]],
  ['colorsensor',['colorSensor',['../classcolor_sensor.html#a1c84d4083ecb53645ad6b85a0d3bc682',1,'colorSensor']]]
];
