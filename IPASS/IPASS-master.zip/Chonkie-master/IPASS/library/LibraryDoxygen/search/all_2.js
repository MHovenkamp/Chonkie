var searchData=
[
  ['getcolor',['getColor',['../classcolor_sensor.html#af43a261c69694b37dfd8fd15da1005a3',1,'colorSensor']]],
  ['getlightintensity',['getlightIntensity',['../classcolor_sensor.html#a344bee4b71d2f1fff1c1de462ad106f5',1,'colorSensor']]],
  ['getrgb',['getRGB',['../classcolor_sensor.html#a9ab1560a1d829b1571059818e099ede0',1,'colorSensor']]]
];
