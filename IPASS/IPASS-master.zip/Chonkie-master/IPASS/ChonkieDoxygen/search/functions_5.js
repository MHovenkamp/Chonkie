var searchData=
[
  ['lives',['lives',['../classlives.html#add558125e9f090ee2e2e9bbca461c886',1,'lives']]]
];
