var searchData=
[
  ['eat',['eat',['../classchonkie.html#a31e2cbf97b386600f9011ae02f5fe013',1,'chonkie']]]
];
