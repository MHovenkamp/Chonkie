var searchData=
[
  ['managehealth',['manageHealth',['../classlives.html#a12e331847d25bb4de37a13c8d9a86209',1,'lives']]]
];
