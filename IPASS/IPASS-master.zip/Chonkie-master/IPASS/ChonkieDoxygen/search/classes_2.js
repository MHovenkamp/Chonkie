var searchData=
[
  ['lives',['lives',['../classlives.html',1,'']]]
];
