var searchData=
[
  ['updateidle',['updateIdle',['../classchonkie.html#a1413cb41e2a4bf3b8b9aafd3c978828a',1,'chonkie']]]
];
