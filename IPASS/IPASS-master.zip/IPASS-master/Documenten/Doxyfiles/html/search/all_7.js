var searchData=
[
  ['precision',['precision',['../class_b_m_p280.html#a768108169701cd2311f433814f01da03',1,'BMP280']]]
];
