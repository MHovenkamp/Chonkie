var searchData=
[
  ['bmp280',['BMP280',['../class_b_m_p280.html#a6f61e0878f974c53b049d3d79af68865',1,'BMP280']]],
  ['boschbm',['BoschBM',['../class_bosch_b_m.html#a09c795e104995f604c56fc8274fdb64b',1,'BoschBM']]],
  ['burstread',['burstRead',['../class_bosch_b_m.html#aa0b192d6002ef7b65f9d450861d16559',1,'BoschBM']]]
];
